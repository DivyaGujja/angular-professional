import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    var_one:string = "nareshit";
    var_two:string = "NARESHIT";
    var_three:string = "naresh it";
    var_four:any = {p_id:111,
                    p_name:'p_one',
                    p_cost:10000};
    var_five:number = 0.9;
    var_six:number = 100;
    var_seven:Array<any> = [10,20,30,40,50];
    var_eigth:number = 100.12345;
    var_nine:Date = new Date();
    /************************************/
      var_ten:string = "Hello";
    /************************************/
}
