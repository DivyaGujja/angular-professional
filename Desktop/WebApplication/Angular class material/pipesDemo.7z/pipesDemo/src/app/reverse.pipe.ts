import { Pipe } from "@angular/core";
@Pipe({
    name : "reverse"
})
export class ReversePipe{
    transform(arg1){
        var data = "";
        for(var i:number=0;i<arg1.length;i++){
            data = arg1[i]+data;
        };
        return data;
    };
};