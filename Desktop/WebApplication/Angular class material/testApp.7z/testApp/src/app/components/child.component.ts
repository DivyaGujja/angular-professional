import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'child',
  templateUrl: './child.component.html',
  styles: []
})
export class ChildComponent implements OnInit {
  @Input() p_id;
  @Input() p_name;
  @Input() p_cost;
  @Output() sendData:EventEmitter<any> = new EventEmitter();
  constructor() { }
  ngOnInit() {
  }
  clickMe():any{  
     this.sendData.emit(this.p_id+"...."+this.p_name+"...."+this.p_cost);
  };
}
