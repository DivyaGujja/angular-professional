/*
    this file used to store the server side token
*/
module.exports = {
    "token" : ""
};